$('#toastActivator').on('click', () => $('.toast').toast('show'));

$('#modal_OK').on('click', () => {
    alert("OK - tutaj można wykonać jakąś akcję!");
})